Marco Salinas : 201273589-0

Para compilar ejecutar make en terminal.